package corp.blayzer.randomit;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class DisplayResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_result);


//        Get the Intent that started this activity and extract the integer
        Intent intent= getIntent();
        int intValue = intent.getIntExtra("intValName",0);

//        Capture the layout's TextView and set the Integer as its text
        TextView textNumView = (TextView) findViewById(R.id.textNumView);
        textNumView.setText(Integer.toString(intValue));
    }
}
