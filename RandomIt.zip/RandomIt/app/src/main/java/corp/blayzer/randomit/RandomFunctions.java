package corp.blayzer.randomit;

/**
 * Created by Dor-B on 26/05/2017.
 */
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import java.util.Random;
import java.util.function.Function;

public class RandomFunctions {

    public int CalculateNums (Integer lowVal,Integer highVal)
    {

        Random rand = new Random(); // Create a new object of type random
        int resultVal = rand.nextInt((highVal - lowVal) + 1) + lowVal;  //highVal is the maximum and lowVal is our minimum value

        return resultVal; // return the random value
    }

    }



